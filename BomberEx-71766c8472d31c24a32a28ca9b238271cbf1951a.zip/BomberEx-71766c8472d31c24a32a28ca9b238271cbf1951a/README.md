# BomberEx
C# Email bomber

Compile and use.
Copy a senders.txt, message.txt, words.txt from BomberEx/BomberEx/bin/Release/ to this same directory of ur .exe
